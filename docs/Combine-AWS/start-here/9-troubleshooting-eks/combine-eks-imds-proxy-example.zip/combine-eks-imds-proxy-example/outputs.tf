output "cluster_name" {
  value = aws_eks_cluster.this.name
}

output "cluster_endpoint" {
  description = "The EKS Cluster API endpoint. Read through Combine, this is the Combine Kubernetes Proxy endpoint."
  value       = aws_eks_cluster.this.endpoint
}

output "node_role_arn" {
  value = aws_iam_role.node.arn
}

output "update_kubeconfig_command" {
  value = "aws eks update-kubeconfig --region ${var.region} --name ${aws_eks_cluster.this.name}"
}
