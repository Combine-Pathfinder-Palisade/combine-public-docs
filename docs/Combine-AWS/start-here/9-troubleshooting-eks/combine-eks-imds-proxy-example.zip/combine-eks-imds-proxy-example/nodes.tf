resource "aws_launch_template" "node" {
  name_prefix = "${var.cluster_name}-node-"

  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = var.imds_http_tokens
    http_put_response_hop_limit = 2
  }

  user_data = base64encode(templatefile("${path.module}/node-user-data.tftpl", {
    cluster_name   = var.cluster_name
    package_url    = var.imds_proxy_package_url
    ca_certificate = trimspace(var.combine_ca_certificate)
    partition      = var.imds_proxy_partition
    domain         = var.imds_proxy_domain
    region_map     = var.imds_proxy_region_map
    az_id_map      = var.imds_proxy_az_id_map
  }))

  tag_specifications {
    resource_type = "instance"
    tags          = { Name = "${var.cluster_name}-node" }
  }
}

resource "aws_eks_node_group" "this" {
  cluster_name    = aws_eks_cluster.this.name
  node_group_name = "${var.cluster_name}-nodes"
  node_role_arn   = aws_iam_role.node.arn
  subnet_ids      = var.node_subnet_ids
  ami_type        = "AL2023_x86_64_STANDARD"
  instance_types  = var.node_instance_types

  scaling_config {
    desired_size = var.node_desired_size
    min_size     = var.node_min_size
    max_size     = var.node_max_size
  }

  launch_template {
    id      = aws_launch_template.node.id
    version = aws_launch_template.node.latest_version
  }

  labels = { "combine.io/imds-proxy" = "enabled" }

  # The VPC CNI must trust the Combine Certificate Authority before the first Node starts aws-node.
  depends_on = [aws_iam_role_policy_attachment.node, aws_eks_addon.vpc_cni]
}
