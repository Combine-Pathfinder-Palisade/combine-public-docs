provider "aws" {
  region = var.region

  # The Combine Certificate Authority must be trusted. Install it in the operating system trust store, or point to it here.
  custom_ca_bundle = var.combine_ca_bundle_file
}

data "aws_partition" "current" {}

data "aws_service_principal" "eks" {
  service_name = "eks"
}

data "aws_service_principal" "ec2" {
  service_name = "ec2"
}
