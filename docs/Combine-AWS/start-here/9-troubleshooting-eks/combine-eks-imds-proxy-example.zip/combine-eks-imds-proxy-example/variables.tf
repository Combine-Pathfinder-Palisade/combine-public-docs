variable "region" {
  description = "The Emulated Region to create the EKS Cluster in."
  type        = string
  default     = "us-iso-east-1"
}

variable "cluster_name" {
  description = "The EKS Cluster name."
  type        = string
  default     = "combine-imds-proxy-example"
}

variable "kubernetes_version" {
  description = "The Kubernetes version. It must be supported in the Emulated Partition."
  type        = string
  default     = "1.35"
}

variable "iam_role_permissions_boundary_arn" {
  description = "The permissions boundary that your Combine Deployment requires on IAM Roles you create (for example, arn:aws-iso:iam::123456789012:policy/PB-<VpcName>-WLDEVELOPER-C2E-TS). Leave null if none is required."
  type        = string
  default     = null
}

variable "vpc_id" {
  description = "The Combine VPC."
  type        = string
}

variable "cluster_subnet_ids" {
  description = "Subnets for the EKS Cluster's network interfaces (at least two Availability Zones)."
  type        = list(string)
}

variable "node_subnet_ids" {
  description = "Subnets for the Nodes."
  type        = list(string)
}

variable "combine_endpoints_security_group_id" {
  description = "The Combine Endpoint Server Security Group (<VpcName>-SG-Endpoints, Combine-SG-Endpoints by default). It needs HTTPS access to the EKS Cluster API for the Combine Kubernetes Proxy."
  type        = string
}

variable "combine_ca_bundle_file" {
  description = "Optional path to the Combine Certificate Authority for the AWS provider. Leave null if the operating system trust store already trusts it."
  type        = string
  default     = null
}

variable "combine_ca_certificate" {
  description = "PEM contents of the Combine Certificate Authority (certificates/ca.cert.pem from your Credential Package), installed on every Node."
  type        = string
}

variable "imds_proxy_package_url" {
  description = "A URL the Nodes can download the Combine IMDS Proxy package (combine-imds-proxy-linux.tar.gz) from, for example a presigned S3 URL or an internal web server."
  type        = string
}

variable "imds_proxy_partition" {
  description = "COMBINE_IMDS_PARTITION: the Emulated Partition ID."
  type        = string
  default     = "aws-iso"
}

variable "imds_proxy_domain" {
  description = "COMBINE_IMDS_DOMAIN: the Emulated DNS Suffix."
  type        = string
  default     = "c2s.ic.gov"
}

variable "imds_proxy_region_map" {
  description = "COMBINE_IMDS_MAP_REGION: comma-separated host Region=Emulated Region pairs. It must match the Region mapping of your Combine Deployment."
  type        = string
  default     = "us-east-1=us-iso-east-1"
}

variable "imds_proxy_az_id_map" {
  description = "COMBINE_IMDS_MAP_AZ_ID: comma-separated host Availability Zone ID prefix=Emulated prefix pairs, one for each mapped Region."
  type        = string
  default     = "use1=usie1"
}

variable "imds_http_tokens" {
  description = "IMDS HttpTokens for the Nodes: required (IMDSv2 only) or optional (IMDSv1 and IMDSv2). The Combine IMDS Proxy supports both."
  type        = string
  default     = "required"

  validation {
    condition     = contains(["required", "optional"], var.imds_http_tokens)
    error_message = "imds_http_tokens must be required or optional."
  }
}

variable "node_instance_types" {
  description = "Node instance types."
  type        = list(string)
  default     = ["t3.medium"]
}

variable "node_desired_size" {
  type    = number
  default = 2
}

variable "node_min_size" {
  type    = number
  default = 1
}

variable "node_max_size" {
  type    = number
  default = 3
}
