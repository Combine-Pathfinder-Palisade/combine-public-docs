# Combine EKS Cluster with the Combine IMDS Proxy

This TerraForm example builds an EKS Cluster in a Combine VPC whose Nodes run the Combine IMDS Proxy. It requires Combine 3.15.2 or later.

Each Node:

- installs the Combine Certificate Authority and the Combine IMDS Proxy from its UserData, so every process and Pod on the Node reads the Emulated Partition, Region, and Availability Zone from IMDS
- joins the Cluster through the Combine Kubernetes Proxy, on its first boot and every boot after

For how this works, see [IMDS on EKS](https://docs.sequoiacombine.io/Combine-AWS/start-here/troubleshooting-eks/guidance-imds).

## What It Builds

| File | Resources |
| --- | --- |
| `iam.tf` | The Cluster IAM Role and the Node IAM Role, both prefixed with `PROJECT_` |
| `cluster.tf` | A Security Group that lets the Combine Endpoint Server reach the Cluster API, the EKS Cluster (private endpoint only), and the `vpc-cni` and `aws-ebs-csi-driver` add-ons |
| `nodes.tf`, `node-user-data.tftpl` | A launch template with the Node UserData, and an EKS managed node group on the Amazon Linux 2023 EKS AMI |

## Before You Begin

- Run TerraForm from inside the Combine VPC (for example, from the Combine Proxy), with credentials for the `WLDEVELOPER` IAM Role, as for any other Combine work.
- Trust the Combine Certificate Authority, in the operating system trust store or with `combine_ca_bundle_file`.
- Make sure the Combine Kubernetes Proxy is enabled for the Cluster (the default).
- Host the Combine IMDS Proxy package (`combine-imds-proxy-linux.tar.gz`) where the Nodes can download it while they boot, without credentials: on a web server inside the Combine VPC, or as an S3 presigned URL that you create through Combine for the emulated Region. The Combine Firewall blocks presigned URLs for S3 in the host Region. A presigned URL expires after at most 7 days, and Nodes that launch after that cannot install the Combine IMDS Proxy.
- Look up the permissions boundary that your Combine Deployment requires on IAM Roles you create (`PB-<VpcName>-WLDEVELOPER-C2E-TS` for `WLDEVELOPER` in C2S), the Combine Endpoint Server Security Group (`<VpcName>-SG-Endpoints`, `Combine-SG-Endpoints` by default), and the customer subnets of your Combine VPC.
- Nodes pull the EKS add-on images from ECR in the host Region. In a Combine VPC with the Combine Firewall, keep the `EnableAirgapAccessEKS` CloudFormation Parameter set to `true` (the default).

## Usage

```bash
cp terraform.tfvars.example terraform.tfvars   # then fill in your values
terraform init
terraform plan
terraform apply
```

Set the Combine IMDS Proxy variables (`imds_proxy_*`) to match your Combine Deployment's Region mapping. The defaults are for C2S with the default Region mapping.

## Verify

```bash
$(terraform output -raw update_kubeconfig_command)
kubectl get nodes -o custom-columns='NAME:.metadata.name,PROVIDER:.spec.providerID'
```

Every Node is `Ready` and has an emulated provider ID (for example, `aws:///us-iso-east-1a/i-...`). On a Node, `/var/log/combine-imds-proxy-userdata.log` ends with `Combine: kubelet will use https://...eks.c2s.ic.gov`.

## Things to Know

- **Pods that use IRSA** get `AWS_REGION` set to the host Region by EKS. Set `AWS_REGION` and `AWS_DEFAULT_REGION` to the Emulated Region in the Pod spec to send their AWS API calls through Combine.
- **Pods that call AWS** must trust the Combine Certificate Authority.
- **The Cluster Autoscaler** works with these Nodes and Combine's default rewrite. Do not set the Cluster Autoscaler exemption Configuration Values.
- **Changing the UserData** creates a new launch template version, so the node group replaces its Nodes.

## Clean Up

```bash
terraform destroy
```
