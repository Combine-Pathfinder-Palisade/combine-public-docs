resource "aws_security_group" "cluster_combine_access" {
  name        = "${var.cluster_name}-combine-endpoints"
  description = "Combine Endpoint Server access to the EKS Cluster API (Combine Kubernetes Proxy)"
  vpc_id      = var.vpc_id
}

resource "aws_vpc_security_group_ingress_rule" "cluster_combine_access" {
  security_group_id            = aws_security_group.cluster_combine_access.id
  referenced_security_group_id = var.combine_endpoints_security_group_id
  ip_protocol                  = "tcp"
  from_port                    = 443
  to_port                      = 443
}

resource "aws_eks_cluster" "this" {
  name     = var.cluster_name
  version  = var.kubernetes_version
  role_arn = aws_iam_role.cluster.arn

  access_config {
    authentication_mode                         = "API"
    bootstrap_cluster_creator_admin_permissions = true
  }

  vpc_config {
    subnet_ids              = var.cluster_subnet_ids
    security_group_ids      = [aws_security_group.cluster_combine_access.id]
    endpoint_private_access = true
    endpoint_public_access  = false
  }

  depends_on = [aws_iam_role_policy_attachment.cluster]
}

# aws-node calls EC2 through Combine once IMDS reports the Emulated Region, but it verifies TLS with its own certificate
# bundle. Mount the Node's bundle, which the Node UserData adds the Combine Certificate Authority to.
resource "aws_eks_addon" "vpc_cni" {
  cluster_name                = aws_eks_cluster.this.name
  addon_name                  = "vpc-cni"
  resolve_conflicts_on_create = "OVERWRITE"
  resolve_conflicts_on_update = "OVERWRITE"

  configuration_values = jsonencode({
    extraVolumes      = [{ name = "host-ca-bundle", hostPath = { path = "/etc/pki/ca-trust/extracted/pem", type = "Directory" } }]
    extraVolumeMounts = [{ name = "host-ca-bundle", mountPath = "/host-ca", readOnly = true }]
    extraEnv          = [{ name = "SSL_CERT_FILE", value = "/host-ca/tls-ca-bundle.pem" }]
  })
}

# The EBS CSI node plugin runs as a Pod, so it would read the emulated Availability Zone from IMDS and collide with the
# host Availability Zone in the Node's topology label. Read the Node's labels instead.
resource "aws_eks_addon" "ebs_csi" {
  cluster_name                = aws_eks_cluster.this.name
  addon_name                  = "aws-ebs-csi-driver"
  resolve_conflicts_on_create = "OVERWRITE"
  resolve_conflicts_on_update = "OVERWRITE"

  configuration_values = jsonencode({
    node = { metadataSources = "kubernetes" }
  })

  depends_on = [aws_eks_node_group.this]
}
