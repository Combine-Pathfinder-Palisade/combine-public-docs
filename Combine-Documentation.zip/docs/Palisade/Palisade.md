# What's Palisade?

Our newest product line, a white-glove implementation of the AWS TSE architecture for NATO regions.

TSE Docs here:
- https://github.com/aws-samples/landing-zone-accelerator-on-aws-for-tse-se/blob/main/install.md
- https://github.com/aws-samples/landing-zone-accelerator-on-aws-for-tse-se/tree/main
- https://catalog.workshops.aws/tse-sensitive-edition/en-US/deployment/tse-config-preparation/config-setup
