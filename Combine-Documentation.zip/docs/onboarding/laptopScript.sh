#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

# Update and upgrade Homebrew
printf "🔧 Updating and upgrading Homebrew..."
brew update && brew upgrade

# Install Node.js
printf "🚀 Installing Node.js..."
brew install node

# Install Java (OpenJDK)
printf "💻 Installing Java (OpenJDK)..."
brew install openjdk
# Add OpenJDK to PATH if not already done
printf "📝 Adding OpenJDK to PATH..."
echo 'export PATH="/usr/local/opt/openjdk/bin:$PATH"' >> ~/.zshrc
source ~/.zshrc

# Install Git
printf "📚 Installing Git..."
brew install git

# Install AWS CLI
printf "📦 Installing AWS CLI..."
brew install awscli

# Install Azure CLI
printf "🖥️ Installing Azure CLI..."
brew install azure-cli

# Install Docker (Docker Desktop)
printf "🐳 Installing Docker Desktop..."
brew install --cask docker
printf "🐳 Note: After installation, open Docker Desktop and complete the setup."

# Install Visual Studio Code
printf "🖋️ Installing Visual Studio Code..."
brew install --cask visual-studio-code

# Install Terraform
printf "🌐 Installing Terraform..."
brew install terraform

# Verification of installations
printf "🔍 Verifying installations..."
node -v && printf "🚀 Node.js installed successfully"
java -version && printf "💻 Java installed successfully"
git --version && printf "📚 Git installed successfully"
aws --version && printf "📦 AWS CLI installed successfully"
az --version && printf "🖥️ Azure CLI installed successfully"
docker --version && printf "🐳 Docker installed successfully"
terraform -v && printf "🌐 Terraform installed successfully"

printf "🎉 All tools installed successfully!"
