# Tools We Use

- 🦉 [Thena](https://app.thena.ai) for ticketing
- [Github](https://github.com/Combine-Pathfinder-Palisade) for code, automation, Project Tracking (Github Spaces probably)
- [AWS](https://us-east-1.console.aws.amazon.com) for Combine AWS-related work
  - AWS Government for customers who want Combine in Gov, sign-in links vary per customer
- [Azure](https://portal.azure.com) for Combine Azure-related work 
  - [Azure Government](https://portal.azure.us) for customers who want Combine in Gov
- [env0](https://app.env0.com) for IaC in Combine Azure