# Pathfinder

Is a web application to find paths.

TODO discuss deployment via ECR, how to set up local, docker, etc