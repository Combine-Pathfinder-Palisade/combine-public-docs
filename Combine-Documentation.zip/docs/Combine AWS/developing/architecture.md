# Architecture

### A detailed walkthrough of the Combine AWS Architecture


A diagram:
![Combine Architecture](/aws/combine-architecture.png)


TODOs:
- add information about Combine consisting of cloudformation + assets
- add content for each project - `combine-commons`, `combine-tap`, `combine-endpoints` and `combine-account-automation`

### Instance Refresh

TODO add instructions on how to do an instance refresh