# The Combine Automation Tool

TODO write description of the Automation tool, how we use it, what a `CombineCommand` is, etc