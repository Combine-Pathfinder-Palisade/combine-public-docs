# Connecting to the Bastion Server via SSH

1. Log in to the AWS interface.
2. Navigate to **"Instances"**.
3. Find the server instance name that matches the intended bastion target.
4. Note the public IPv4 address / dns name.

---

# Navigate to S3

1. Find the bucket that matches the naming convention of the target host.
   - In this instance, navigate to the **"public"** directory.
2. Locate the file **"admin.zip"**.
3. Dig for **"Combine.pem"**.

---

# Connect via SSH

1. Modify the permissions on the **"Combine.pem"** key with the following command

   ```bash
   chmod 600 /path/to/key/Combine.pem
   ```

2. Use the Combine.pem key to ssh in to the target bastion server:

   ```bash
   ssh -i /path/to/key/Combine.pem ec2-user@ec2-1-2-3-4.compute-1.amazonaws.com
   ```