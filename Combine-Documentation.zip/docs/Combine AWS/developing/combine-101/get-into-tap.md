# Connecting to the TAP Server via SSH

1. Start by creating an SSH connection in to the bastion server
 - See 'get-into-bastion' if a connection to the bastion server has not yet been established

 # Locate the CombineRestricted.pem key

1. Return to the S3 bucket that contained the original Combine.pem key used to connect to the bastion host.
2. Search within this bucket or other related buckets for the CombineRestricted.pem key

# SCP the CombineRestricted.pem key on to the bastion host

1. Transfer the restricted key on to the bastion using SCP
2. Open a second terminal window on the local system and use the following syntax:

   ```bash
   scp -i /path/to/key/Combine.pem /local/path/to/CombineRestricted.pem ec2-user@ec2-1-2-3-4.compute-1.amazonaws.com:/home/ec2-user
   ```
3. Note that the syntax is as follows: 

   ```bash
   scp -i <bastion_key.pem> <local_copy_of_CombineRestricted.pem> <remote_username>@<remote_system_dns_name>:<remote_filepath_for_upload>
   ```