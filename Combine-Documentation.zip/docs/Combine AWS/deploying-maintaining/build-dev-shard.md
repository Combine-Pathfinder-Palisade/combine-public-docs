# Building a Developer Shard

## Prerequisites
1. maven
2. java openjdk 17
3. Bouncy Castle encryption library `bcprov-jdk18on-1.78.1.jar` in `combine-aws/account-automation/lib/`

## Each developer can create their own shard (set of Combine servers) for test purposes.

1. Find the `combine-provisioning.yaml` CloudFormation template located at `combine-account-automation/src/main/resources/com/sequoia/combine/templates/provisioning/combine-provisioning.yaml`
2. Navigate to "CloudFormation" on AWS (https://us-east-1.console.aws.amazon.com/cloudformation/)
3. Find "Stacks" and click "Create Stack" > Select "With new resources"
4. For "Prerequisite - Prepare template" select "Choose an existing template"
5. For "Specify Template" select "Upload a template file"
 - Choose the `combine-provisioning.yaml` file referenced in the first step
6. Click "Next"
7. Name this stack "`Combine-<FirstInitial><LastName>`"
8. Parameters should specify `ExistingProvisioningRoleArn` 
 - Use the "arn:aws:iam::663117128738:role/Combine-Provisioning-Role" for this value
9. Click "Next"
10. For "Configure stack options" leave all settings as they are up to "Capabilities"
11. Under "Capabilities" click the checkbox next to "I acknowledge that AWS CloudFormation might create IAM resources with custom names."
11. Click "Next"
12. For "Review and create" leave all settings as they are and click "Submit"
13. The browser should proceed to a menu under "Cloudformation > Stacks > Combine-FirstInitialLastname"
 - The tab "Events - updated" will be selected
 - The current status should show as `CREATE_IN_PROGRESS`
 - After a couple minutes the status should change to `CREATE_COMPLETE`

2. Pull the latest tag for the `combine-aws` repository. (e.g., `git tag -l` then `git checkout <latest_tag>`)
 - Use the following sytax to list the create date of each tag:
 
 ```bash
 git for-each-ref --format='%(refname:short) %(creatordate)' refs/tags
 ```
 - Take note of this value as it will be needed when deploying the installation to AWS
 - The following bash one-liner will check for the latest tag and then check it out automatically:
 
 ```bash
 git for-each-ref --sort=-creatordate --format='%(refname:short)' refs/tags | head -n 1 | xargs git checkout
 ```
 
3. Create a `clients.json` entry for your shard (located at `combine-account-automation/clients.json`) AWS Account Number and Role ARN from Step 1. Note: You will need to add this change to the `master` branch since you are working in a tag.
 - Here is an example json entry for addition to clients.json:
 ```bash
   "combineExample": {
      "region": "us-east-1",
      "masterRegion": "us-east-1",
      "shardId": "Example",
      "clientAccountId": "663117128738",
      "clientRoleArn": "arn:aws:iam::663117128738:role/Combine-Provisioning-Role",
      "bucketEncryptionKey": "",
      "followerType": "None",
      "buildTS": "true",
      "buildS": "false",
      "buildGovCloud": "false",
      "certificateName": "Combine Example",
      "templateParameters": {
        "combine.yaml": {
        },
        "combine-policy.yaml": {
        },
        "combine-vpc.yaml": {
        }
      }
	}

 ```
### STUCK HERE AS OF 01/14/2024

4. Build and deploy the Combine components:
    - for versions 3.13 and later: 
      - Perform a `mvn clean package install` in root directory of the `combine-aws` repository. This will build all Combine components and package them as needed.
	  - Perform the actual deploy:
        - On Mac/Linux: `java -classpath "combine-account-automation/lib/*:combine-account-automation/target/*" com.sequoia.combine.accounts.CombineCommandExecutor full --config-store-profile <customer name from clients.json> --bricks-release-version <version number>` (Bricks Version numbers use the format: `bricks_v_<major>_<minor>`.)
		  - Example command: `java -classpath "combine-account-automation/lib/*:combine-account-automation/target/*" com.sequoia.combine.accounts.CombineCommandExecutor full --config-store-profile combineExample --bricks-release-version bricks_v_3_13_1_1`
        - On Windows: `java -classpath lib/*;target/* com.sequoia.combine.accounts.CombineCommandExecutor full --config-store-profile <customer name from clients.json> --bricks-release-version <version number>` (Bricks Version numbers use the format: `bricks_v_<major>_<minor>`.)
    - for versions prior to 3.13:
      - Perform a `npm i && npm run build` in the `combine-tap/tap-dashboard` directory.
      - Perform a `mvn clean install` on the following directories:
        - `combine-commons`
        - `combine-tap/tap-api`
        - `combine-endpoints`
      - Perform a `mvn clean package install` on `combine-account-automation`
      - Run the following command:
        - `mvn exec:java -q "-Dexec.args=full --config-store-profile {CUSTOMER_NAME_FROM_CLIENTS.JSON} --bricks-release-version bricks_v_3_12"`

    - The following prompts will be displayed on execution:
      - Configuration Store File not found!
      - Enter Client AWS Account ID: `<enter account ID>`
      - Enter Shard ID (optional): CShrout
      - Enter Region: us-east-1
      - Enter Master Region: us-east-1
      - Use JSON STS Token Credentials?: no
      - Enter Client Account Access Key : `<enter access key>`
      - Enter Client Account Access Key Secret: `<enter access key secret>`
      - Enter Client Account Session Token (optional): 
      - Has User Management Account?: no
      - Enter DevOps Bucket Encryption Key (optional): 
      - Loading parameter [bricksReleaseVersion] value [bricks_v_3_13_1_1] from store.
      - Enter Client Certificate Name: CShrout Certificate
      - Build Top Secret region emulation?: yes
      - Build Secret region emulation?: no
      - Build GovCloud region emulation?: no

5. If the tool runs with no errors, you should be able to log into their AWS account and see Combine resources being created. 

6. After the tool completes navigate to the TAP Dashboard using the admin certificates downloaded from the link provided (or you can retrieve the `admin.zip` from the `combine-app-storage-<account number>-public` bucket) and add any additional users the customer requires. Once they receive their credentials, they often need help authenticating - this often happens live during the onboarding session.

7. Update our customer list: [Customer Accounts Spreadsheet](https://sequoiaholdingsllc-my.sharepoint.com/:x:/g/personal/bking_sequoiainc_com/EfVi7XircpJIsS2v8HHknPcBuRV2Lh3efr3AHteAP_VEcA?e=WfGGpt)

8. You also need to add an entry for the customer in the `combine-aws-customers/customers` repo. This includes the certs, `passwords.txt` file, `tap.txt` file, `README.txt`, etc.
    - `tap.txt` should contain the url of the Load Balancer that points to the customer's TAP Autoscaling group.
