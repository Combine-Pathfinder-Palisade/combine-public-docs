# Support Duties

Support goes from Tuesday - Tuesday.

If it's your week on Support:

- keep track of thena - move requests from 'Waiting on Us' to 'Waiting on Customer', close requests, follow up where needed.
- ask for help if support swarms
- during downtime, update documentation, see the [open issues on the repo](https://github.com/Combine-Pathfinder-Palisade/combine-docs/issues).
