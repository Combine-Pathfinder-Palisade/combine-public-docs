# Customer Contacts Spreadsheet

### CHANGES VIA THIS EMBEDDED VIEW WILL NOT BE SAVED; you can edit it [here](https://sequoiaholdingsllc-my.sharepoint.com/:x:/g/personal/bking_sequoiainc_com/EfVi7XircpJIsS2v8HHknPcBuRV2Lh3efr3AHteAP_VEcA?e=Xglp3Y&nav=MTVfezA2NjUyMzhDLTBCQUQtOEM0RS1BNzA2LTNBMUZBNDZGRjg5Q30)

<iframe width="900" height="900" frameborder="0" scrolling="no" src="https://sequoiaholdingsllc-my.sharepoint.com/personal/bking_sequoiainc_com/_layouts/15/Doc.aspx?sourcedoc={78ed62f5-72ab-4892-b12d-aff071e49cf7}&action=embedview&AllowTyping=True&ActiveCell='Sheet1'!A4&wdHideGridlines=True&wdDownloadButton=True&wdInConfigurator=True&wdInConfigurator=True"></iframe>